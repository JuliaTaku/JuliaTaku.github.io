let img;
let m = true;
let o = true;
function jumper() {
    //define jumper start position and dimensions
    this.x = 200;
    this.y = 100;
    this.width = 150;
    this.height = 150;
    //force of gravity
    this.gravity = 0.5;
    //opposing force
    this.lift = -25;
    //velocity
    this.velocity = 0;
    //show what the object looks like
    this.show = function() {
        image(img,this.x,this.y,150,150);
    } 
    //what happens when I the object jumps
    this.jump = function() {
        this.velocity += this.lift;
    }
    //handle updating the object
    this.update = function() {
        this.velocity += this.gravity;
        this.y += this.velocity;
        //air resistance
        this.velocity *= 0.9;
        //stop the object from falling through the floor
        if (this.y > (h-110)) {
            this.y = h-110;
            this.velocity = 0;
        }
        //stop the object from going through the ceiling
        if (this.y < 0) {
            this.y = 0;
            this.velocity = 0;
        }
        if (this.x > (w - 125)) {
            this.x = w-125;
            this.velocity = 0;
        } 
        if (this.x < 0) {
            this.x = 0;
            this.velocity = 0;
        }
    }
}
function block() {
    this.x = 450;
    this.y = 270;
    this.w = 600;
    this.h = 140;
    this.bvelocity = 0;
    this.blockshow = function() {
        rect(this.x,this.y,600,140);
        fill('#4B371C');
    }
}
function monster() {
    this.x = 450;
    this.y = h-135;
    this.w = 150;
    this.h = 150;
    this.velocity = 0;
    this.show = function() {
        image(mon,this.x,this.y,150,150);
    }
    this.move = function(){
        if(this.x <= 0){
            this.x += 4;
            m = true;
        }
        if(this.x >= (w - 125)){
            this.x -= 4;
            m = false;
        }
        if(m == false){
            this.x -=4;
        }
        if(m == true){
            this.x += 4;
        }
    }
}
function monster2() {
    this.x = 900;
    this.y = h-151;
    this.velocity = 0;
    this.show = function() {
        image(mons,this.x,this.y,120,155);
    }
    this.move = function() {
        if(this.x <=0){
            this.x += 6;
            o = true;
        }
        if(this.x >= (w-125)){
            this.x -= 6;
            o = false;
        }
        if(o == false){
            this.x -= 6;
        }
        if(o == true){
            this.x +=6;
        }
    }
}
function power() {
    this.x = 200;
    this.y = 100;
    this.w = 50;
    this.h = 50;
    this.gravity = 0;
    this.velocity = 0;
    this.pshow = function() {
        image(pwr,this.x,this.y,50,50);
    }
}
function power2() {
    this.x = 200;
    this.y = 100;
    this.w = 50;
    this.h = 50;
    this.gravity = 0;
    this.velocity = 0;
    this.pshow = function() {
        image(pwr2,this.x,this.y,50,50);
    }
}
function home() {
    location.href ="home.html";
}