function level1() {
    location.href="level1.html";
}
function level2() {
    location.href="level2.html";
}
function level3() {
    location.href="level3.html";
}
function level4() {
    location.href='level4.html';
}